package Homework;

import java.util.Scanner;

public class Runner {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please enter number of km the runner ran ");
        double kms = scanner.nextDouble();
        double miles = kms*1.6;

        System.out.println("The distance in miles is "+miles);

        Scanner hours = new Scanner(System.in);
        System.out.println("Please enter amount of hours the runner ran ");
        double hrs = hours.nextDouble();

        Scanner minutes = new Scanner(System.in);
        System.out.println("Please enter amount of minutes the runner ran ");
        double minutes = minutes.nextDouble();

        double time = hrs+(minutes/60);

        System.out.println("The total time the runner ran is "+time);

        double speed = miles/time;

        System.out.println("The runner's speed is " +speed +" miles per hour");



    }

}
